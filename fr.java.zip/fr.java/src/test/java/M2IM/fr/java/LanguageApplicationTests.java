package M2IM.fr.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanguageApplicationTests {

	@Test
	void contextLoads() {
	}

}
