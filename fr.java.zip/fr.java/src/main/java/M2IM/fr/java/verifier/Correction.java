package M2IM.fr.java.verifier;

import java.util.ArrayList;
import java.util.List;


public class Correction {

//    String str;


    public List<ElementForCorrection> verify(Phrase phraseStudent, Phrase phraseTeacher) {
        List<ElementForCorrection> correctors = new ArrayList<>();
        PieceChangeable pieceChangeable = new PieceChangeable("str");
        if (phraseStudent.getFixeAndChangeablePieces() != null) {
//            System.out.println(phraseStudent.getFixeAndChangeablePieces().size());
//            System.out.println(phraseTeacher.getPiecesTeacher().size());

            for (int i = 0; i < phraseStudent.getFixeAndChangeablePieces().size(); i++) {
                ElementForCorrection corrector = new ElementForCorrection();
                if (phraseStudent.getFixeAndChangeablePieces().get(i).pieceForCorrectAnswer().equals(pieceChangeable.pieceForStudent())) {
                    corrector.setCorrection(ANSWER.NA);
                    System.out.println(corrector.getAnswer());
                } else if (phraseStudent.getFixeAndChangeablePieces().get(i).pieceForCorrectAnswer().
                        equals(phraseTeacher.getPiecesTeacher().get(i).pieceForCorrectAnswer())) {
                    corrector.setCorrection(ANSWER.TRUE);
                    System.out.println(corrector.getAnswer());
                } else {
                    corrector.setCorrection(ANSWER.FALSE);
                    System.out.println(corrector.getAnswer());
                }
                correctors.add(corrector);
            }

        }
        return correctors;
    }
}



//            for (int i = 0; i < phraseStudent.getFixeAndChangeablePieces().size(); i++) {
//                ElementForCorrection corrector = new ElementForCorrection();
////            System.out.println(phraseStudent.getFixeAndChangeablePieces().get(i).toString().length());
////            System.out.println(phraseTeacher.getPiecesTeacher().get(i).toString().length());
////            for (Piece pieceT: phraseTeacher.getPiecesTeacher()) {
////
//////                System.out.println(pieceT);
//
//                if (phraseStudent.getFixeAndChangeablePieces().get(i).pieceForCorrectAnswer().equals(pieceChangeable.pieceForStudent())) {
//                    corrector.setCorrection(ANSWER.NA);
//                }
////            else if (phraseStudent.getFixeAndChangeablePieces().get(i).equals(phraseTeacher.getPiecesTeacher().get(i))) {
////                corrector.setCorrection(Answer.TRUE);
//////                index += phraseStudent.getFixePieces().get(i).pieceForTeacher().length();
////            }
//                else if (phraseStudent.getFixeAndChangeablePieces().get(i).pieceForStudent().length() !=
//                        phraseTeacher.getPiecesTeacher().get(i).pieceForCorrectAnswer().length()) {
//                    corrector.setCorrection(ANSWER.FALSE);
//                } else {
//                    corrector.setCorrection(ANSWER.TRUE);
////                corrector.setIndex(index);
//                }
//                correctors.add(corrector);
//            }
//
////            return correctors;
//
//        }
//
//        else {System.out.println("Student didn't give an answer");}
//        return correctors;
//

//            }
//            else if (phrase.getPiecesStudent().size() <= i) {
//                corrector.setCorrection(Answer.NA);
//            }
//            else {
//                corrector.setCorrection(Answer.FALSE);
//                corrector.setIndex(index);
//            }

//        if (phrase == null || phrase.getStudentPhrase() == null || phrase.getStudentPhrase().length() == 0) {
//            ElementCorrector corrector = new ElementCorrector();
//            corrector.setCorrection(Answer.NA);
//            correctors.add(corrector);
//        } else {
//
//            String studentPhrase = phrase.getStudentPhrase();
//            for (Piece piece : phrase.getPiecesTeacher()) {
//                ElementCorrector corrector = new ElementCorrector();
//                if (studentPhrase.contains(piece.part)) {
//                    corrector.setCorrection(Answer.TRUE);
//                } else {
//                    corrector.setCorrection(Answer.FALSE);
//                    corrector.setIndex(piece.part.length());
//                }
//                correctors.add(corrector);
//
//            }
//        }
