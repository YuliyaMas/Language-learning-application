package M2IM.fr.java.ui;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class ExerciseConfig {
    @Bean
    CommandLineRunner commandLineRunner2(ExerciceRepository exerciceRepository) {
        return args -> {
            Exercise phrase1 = new Exercise("This is a #test# phrase");
            Exercise phrase2 = new Exercise("It is a #correct# answer");
            Exercise phrase3 = new Exercise("You are a #perfect# student!");
            Exercise answer1 = new Exercise("This is a test phrase");
            Exercise answer2 = new Exercise("It is a correct answer");
            Exercise answer3 = new Exercise("You are a perfect student!");
            phrase1.setName("Exercise 1");
            phrase2.setName("Exercise 2");
            phrase3.setName("Exercise 3");
            List<Exercise> phrasesList = new ArrayList<>();
            phrasesList.add(phrase1);
            phrasesList.add(phrase2);
            phrasesList.add(phrase3);
            exerciceRepository.saveAll(phrasesList);
        };
    }
}
