package M2IM.fr.java.verifier;

public class ElementForCorrection {
    private ANSWER answer;

    private Piece answerStudent;

    private Piece correctAnswer;

    public ANSWER getAnswer() {

        return answer;
    }

    public void setCorrection(ANSWER answer) {

        this.answer = answer;
    }

    public Piece getAnswerStudent() {
        return answerStudent;
    }

    public Piece getCorrectAnswer() {
        return correctAnswer;
    }
}
