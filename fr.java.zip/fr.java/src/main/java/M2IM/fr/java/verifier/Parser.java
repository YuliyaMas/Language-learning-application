package M2IM.fr.java.verifier;

import java.util.List;

public interface Parser {
//    parsing teacher's phrase
    List<Piece> parse(String phrase);

    List<Piece> parseForAnswer(String phrase);
}
