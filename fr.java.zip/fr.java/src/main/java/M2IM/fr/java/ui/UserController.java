package M2IM.fr.java.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Objects;

@Controller
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }


    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("student", new Student());
        return "index";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("student") Student student, RedirectAttributes redirAttrs) {
        String redirect = "teacher";

        Student studentDB = userService.getStudentByEmail(student.getEmail());
        if(studentDB == null || !student.getPassword().equals(studentDB.getPassword())){
            redirect = "errorlogin";
        }

        if (Objects.equals(studentDB.getRole(), "student")) {
            redirect = "student";
        }
        redirAttrs.addFlashAttribute("studentId", studentDB.getId());
        return "redirect:/" + redirect;
    }

    @GetMapping("/student")
    public String getExercises(Model model) {
        model.addAttribute("exercises", userService.getExercices());
        Long studentId = (Long) model.getAttribute("studentId");
        model.addAttribute("studentId", userService.getStudent(studentId));
        return "student";
    }

    @GetMapping("/student/{id}")
    public String getStudentId(@PathVariable(value = "id") Long id, Model model) {
//        Long studentId = (Long) model.getAttribute("studentId");
//        model.addAttribute("studentId", userService.getStudent(studentId));
        Student studentId = userService.getStudent(id);
        model.addAttribute("studentId", studentId);
        model.addAttribute("exercises", userService.getExercices());
        return "student";
    }

    @GetMapping("/executeexercise/{id}")
    public String executeExercise (@PathVariable(value = "id") Long id, Model model) {
        Exercise exercise = userService.getExercice(id);
        exercise = userService.generatePhraseForStudent(exercise);
        exercise.setStudentId(1L); //TODO get studentId
        model.addAttribute("exercise", exercise);
        return "executeexercise";
    }

    @GetMapping("/teacher")
    public String getStudents(Model model) {
        model.addAttribute("students", userService.getStudents());
        return "teacher";
    }

    @GetMapping("/addnew")
    public String addNewUser(Model model) {
        Student student = new Student();
        model.addAttribute("student", student);
        return "adduser";
    }

    @PostMapping("/save")
    public String saveUser(@ModelAttribute("student") Student student, Model model) {
        userService.save(student);
        model.addAttribute("student", student);
        return "saveuser";
    }

    @PostMapping("/update")
    public String updateUser(@ModelAttribute("student") Student student, Model model) {
        userService.save(student);
        model.addAttribute("students", userService.getStudents());
        return "teacher";
    }

    @PostMapping("/answer")
    public String verifyAnswer(@ModelAttribute("exercise") Exercise exercise, Model model) {
        userService.verifyAnswer(exercise);
//        userService.generatePhraseForCorrectAnswer(exercise);
        model.addAttribute("exercise", exercise);
        return "result";
    }


    @GetMapping("/updateuser/{id}")
    public String updateUser (@PathVariable(value = "id") Long id, Model model) {
        Student student = userService.getStudent(id);
        model.addAttribute("student", student);
        return "updateuser";
    }


    @GetMapping("/deletestudent/{id}")
    public String deleteStudent(@PathVariable(value = "id") Long id) {
        userService.deleteStudent(id);
        return "redirect:/teacher";

    }

}