package M2IM.fr.java.verifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//public class Test extends ParserRegExp  {
public class Test extends ReadingFile {

//    public Test() {
//        super();
//    }

    public static class Main {
        public static void main(String[] args) throws NoSearchFixePieceException, IOException {
            Test test = new Test();

//            File file = new File("./src.");
//            for(String fileNames : file.list()) {System.out.println(fileNames);}
//            List<Piece> resultParser = test.parse("A named #entity# is a real-world object, such as persons, " +
//                    "locations, #organizations#, etc.");
            String path = "./src/";
            ArrayList<List<Piece>> resultParser = test.readFile(path + "exercice1");
            int total = 0;
            for (List<Piece> parsedPhrase : resultParser) {
                System.out.println("Teacher's phrase contains pieces: " + parsedPhrase);
                Phrase phraseTeacher = new Phrase(parsedPhrase);
                List<Piece> studentPhrase = null;
                Scanner input = new Scanner(System.in);
                try {
                    System.out.println("Please write below your answer ");
                    String answer = input.nextLine();
                    studentPhrase = phraseTeacher.analyseStudentAnswer(answer);
//                    studentPhrase = phraseTeacher.analyseStudentAnswer("A named is a real-world object, such as persons, " +
//                            "locations, organizations, etc.");

                } catch (NoSearchFixePieceException e) {
                    throw new RuntimeException(e);
                }
                Phrase studentPhrase_new = new Phrase(studentPhrase);
                studentPhrase_new.setFixeAndChangeablePieces(studentPhrase);
                Correction correction = new Correction();
                List<ElementForCorrection> resultCorrection = correction.verify(studentPhrase_new, phraseTeacher);
//            for(ElementForCorrection ec : resultCorrection) {
//                System.out.println(resultCorrection);
//            }
//            System.out.println(resultCorrection);
                LevelOfEvaluation level = new LevelOfEvaluation();
                int result = level.chooseEvaluation(resultCorrection, LEVEL.INTERMEDIATE);
                System.out.println(result);
                total  += result;

            }
            System.out.println(total);
        }

    }

}