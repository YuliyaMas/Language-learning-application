package M2IM.fr.java.verifier;

public class PieceChangeable extends Piece {

    public PieceChangeable(String part) {
        super(part);
    }

    public String pieceForTeacher() {
        return "#" + part + "#";
    }
    public String pieceForStudent() {

        return " ... ";
    }
    public String pieceForCorrectAnswer() {

        return part;
    }


}
