package M2IM.fr.java.ui;

import M2IM.fr.java.verifier.ReadingFile;

import javax.persistence.*;

@Entity
@Table

public class Exercise extends ReadingFile {
    @Id
    @SequenceGenerator(name = "exercice_sequence",
            sequenceName = "exercice_sequence",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "exercice_sequence"
    )
    private Long id;

    private String name;

    private String phrase;

    private String wordForAnswer;
    @Transient
    private String phraseForCorrectAnswer;
    private Integer points;

    private String phraseForStudent;

    private String answer;

    private Long studentId;

    public Exercise() {
    }

    public Exercise(String phrase) {
        this.phrase = phrase;
    }

    public String getWordForAnswer() {
        return wordForAnswer;
    }

    public void setWordForAnswer(String wordForAnswer) {
        this.wordForAnswer = wordForAnswer;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public String getPhraseForStudent() {
        return phraseForStudent;
    }

    public void setPhraseForStudent(String phraseForStudent) {
        this.phraseForStudent = phraseForStudent;
    }

    public String getPhrase() {
        return phrase;
    }

    public void setPhrase(String phrase) {
        this.phrase = phrase;
    }

    public String getPhraseForCorrectAnswer() {
        return phraseForCorrectAnswer;
    }

    public void setPhraseForCorrectAnswer(String phraseForCorrectAnswer) {
        this.phraseForCorrectAnswer = phraseForCorrectAnswer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }


    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Exercise{" +
                "id=" + id +
                ", phrase='" + phrase + '\'' +
                '}';
    }
}

