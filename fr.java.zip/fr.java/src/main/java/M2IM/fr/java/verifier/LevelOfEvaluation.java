package M2IM.fr.java.verifier;

import java.util.List;

public class LevelOfEvaluation {

    private Evaluation evaluation;

    public void setEvaluation(Evaluation evaluation) {
        this.evaluation = evaluation;
    }

    public Integer chooseEvaluation(List<ElementForCorrection> correctors, LEVEL level) {
//        int result = 0;
        if (level == LEVEL.BEGINNER) {
            setEvaluation(new EvaluationBeginnerLevel());

        } else if (level == LEVEL.INTERMEDIATE) {
            setEvaluation(new EvaluationIntermediateLevel());
//            result = this.evaluation.doEvaluation(correctors);
        }
        else if (level == LEVEL.ADVANCED) {
            setEvaluation(new EvaluationAdvancedLevel());
//            result = this.evaluation.doEvaluation(correctors);
        }


        return evaluation.doEvaluation(correctors);
    }


}
