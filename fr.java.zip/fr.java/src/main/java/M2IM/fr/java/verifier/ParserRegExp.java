package M2IM.fr.java.verifier;

import java.util.ArrayList;
import java.util.List;


public class ParserRegExp implements Parser {

    @Override
    public List<Piece> parse(String phrase) {
        List<Piece> listPiece = new ArrayList<>();
//        Pattern pattern = Pattern.compile("#");
//        Matcher matcher = pattern.matcher(phrase);
        String[] splittedPhrase = phrase.split("#");
        for (int i = 0; i < splittedPhrase.length; i++) {
//            boolean isWordForChange = true;
            if (i % 2 == 0) {
                listPiece.add(new Piece(splittedPhrase[i].strip()));
//                isWordForChange = false;
            } else {
                listPiece.add(new PieceChangeable(splittedPhrase[i].strip()));
            }
        }

        return listPiece;
    }

    @Override
    public List<Piece> parseForAnswer(String phrase) {
        List<Piece> listPiece = new ArrayList<>();
        List<Piece> listForAnswer = new ArrayList<>();
        String[] splittedPhrase = phrase.split("#");
        for (int i = 0; i < splittedPhrase.length; i++) {
            if (i % 2 == 0) {
                listPiece.add(new Piece(splittedPhrase[i].strip()));

            } else {
                listForAnswer.add(new PieceChangeable(splittedPhrase[i].strip()));
            }
        }

        return listForAnswer;
    }



}