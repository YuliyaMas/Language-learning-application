package M2IM.fr.java.verifier;

import java.util.ArrayList;
import java.util.List;

public class Phrase {

    private List<Piece> fixeAndChangeablePieces = new ArrayList<>();
    private List<Piece> piecesTeacher;
//    List<Piece> piecesStudent = new ArrayList<>();

//    private List<Piece> changeablePieces = new ArrayList<>();
    public Phrase(List<Piece> piecesTeacher) {
        this.piecesTeacher = piecesTeacher;
    }


    public List<Piece> analyseStudentAnswer(String studentPhrase) throws NoSearchFixePieceException {

//        Verify if the student's answer is not empty
        if (studentPhrase != null && studentPhrase.length() != 0) {
            int index = 0;
            int length = 0;
            for (int i = 0; i < piecesTeacher.size(); i++) {
                if (!(piecesTeacher.get(i) instanceof PieceChangeable)) {
                    index = studentPhrase.indexOf(piecesTeacher.get(i).pieceForCorrectAnswer());
                    if (index == -1)
                        throw new NoSearchFixePieceException("This part of phrase is not correct: ", piecesTeacher.get(i));
                    length = piecesTeacher.get(i).pieceForCorrectAnswer().length();
//                    fixePieces.add(new Piece(studentPhrase.substring(index, index + length).strip()));
                    fixeAndChangeablePieces.add(new Piece(studentPhrase.substring(index, index + length).strip()));
                } else {
                    if (i < piecesTeacher.size() - 1) {
                        int indexNextPiece = studentPhrase.indexOf(piecesTeacher.get(i + 1).pieceForCorrectAnswer());
                        if (indexNextPiece == -1)
                            throw new NoSearchFixePieceException("This part of phrase is not correct: ", piecesTeacher.get(i + 1));
//                        changeablePieces.add(new Piece(studentPhrase.substring(index + length, indexNextPiece).strip()));
                        fixeAndChangeablePieces.add(new Piece(studentPhrase.substring(index + length, indexNextPiece).strip()));
                    } else {
//                        changeablePieces.add(new Piece(studentPhrase.substring(index + length).strip()));
                        fixeAndChangeablePieces.add(new Piece(studentPhrase.substring(index + length).strip()));
                    }
//                    return changeablePieces;

                }
            }
        }
        return fixeAndChangeablePieces;
    }

    public List<Piece> getPiecesTeacher() {
        return piecesTeacher;
    }

    public List<Piece> getFixeAndChangeablePieces() {
        return fixeAndChangeablePieces;
    }

//    public List<Piece> getChangeablePieces() {
//
//        return changeablePieces;
//    }

    public Phrase setFixeAndChangeablePieces(List<Piece> fixeAndChangeablePieces) {
        this.fixeAndChangeablePieces = fixeAndChangeablePieces;
        return new Phrase(fixeAndChangeablePieces);
    }
}
