package M2IM.fr.java.ui;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;
public interface ExerciceRepository extends JpaRepository<Exercise, Long> {
    @Query("SELECT points from Student s where s.email = ?1")
    Optional<Integer> getPoints(String email);
}