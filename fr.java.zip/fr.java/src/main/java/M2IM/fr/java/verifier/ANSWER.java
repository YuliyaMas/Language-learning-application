package M2IM.fr.java.verifier;

public enum ANSWER {
    TRUE, FALSE, NA;
}
