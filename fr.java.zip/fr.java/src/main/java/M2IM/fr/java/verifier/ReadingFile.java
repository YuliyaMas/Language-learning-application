package M2IM.fr.java.verifier;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadingFile {
    String filename;
    String ligne;
    int n;

    public ArrayList<List<Piece>> readFile(String filename) throws IOException {
        BufferedReader inputFile = new BufferedReader(new FileReader(filename));
        ParserRegExp parser = new ParserRegExp();
        ArrayList<List<Piece>>  arrayOfPhrasesWithPieces = new ArrayList<>();
        List<Piece> parsingResult;
        while ((ligne = inputFile.readLine()) != null){
            parsingResult = parser.parse(ligne);
            arrayOfPhrasesWithPieces.add(parsingResult);
        }

        return  arrayOfPhrasesWithPieces;
    }
}
