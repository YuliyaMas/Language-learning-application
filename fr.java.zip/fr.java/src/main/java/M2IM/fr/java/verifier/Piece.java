package M2IM.fr.java.verifier;

public class Piece {
    String part;
//    int position;

    public Piece(String part) {
        this.part = part;
//        this.isWordForChange = isWordForChange;
    }

    public String pieceForTeacher() {
        return part;
    }

    public String pieceForStudent() {
        return part;
    }

    public String pieceForCorrectAnswer() {

        return part;
    }

    @Override
    public String toString() {
        return "Piece{" +
                "part='" + part + '\'' +
                '}';
    }
}

