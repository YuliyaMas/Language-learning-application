package M2IM.fr.java.verifier;

public class ExerciceLanguage {
}
