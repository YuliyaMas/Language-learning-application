package M2IM.fr.java.ui;

import M2IM.fr.java.verifier.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ExerciceRepository exerciceRepository;

    @Autowired
    public UserService(UserRepository userRepository, ExerciceRepository exerciceRepository) {
        this.userRepository = userRepository;
        this.exerciceRepository = exerciceRepository;
    }

    public List<Student> getStudents() {
        return userRepository.findAll();
    }

    public void addNewUser(Student student) {

        userRepository.save(student);
    }

    public void save(Student student) {
        userRepository.save(student);
    }

    public Student getStudent(Long id) {
        Student student = userRepository.getReferenceById(id);
        System.out.println(student.getId());
        return student;
    }

    public void deleteStudent(Long id) {
        Student student = userRepository.getReferenceById(id);
        userRepository.delete(student);
    }

    public Student getStudentByEmail(String email) {
        Optional<Student> userByEmail = userRepository.findUserByEmail(email);
        return userByEmail.get();
    }

    public Exercise getExercice(Long id) {
        Exercise exercise = exerciceRepository.getReferenceById(id);
        return exercise;
    }

    public Optional<Integer> getResult(String email) {
        Optional<Integer> points = exerciceRepository.getPoints(email);
//        System.out.println(student.getId());
        return points;
    }

    public void savePoints(Integer points) {
//        exerciceRepository.save(points);
    }


    public List<Exercise> getExercices() {
        return exerciceRepository.findAll();
    }

    public List<Piece> parsingWordsForAnswer(Exercise exercise) {
        ParserRegExp parser = new ParserRegExp();
        List<Piece> parsingWordsForAnswer = parser.parseForAnswer(exercise.getPhrase());
        return parsingWordsForAnswer;
    }
    public void verifyAnswer(Exercise exercise) {
        ParserRegExp parser = new ParserRegExp();
        List<Piece> parsingResult = parser.parse(exercise.getPhrase());
        Phrase phraseTeacher = new Phrase(parsingResult);
        List<Piece> studentPhrase = null;
        try {
            studentPhrase = phraseTeacher.analyseStudentAnswer(exercise.getAnswer());

        } catch (NoSearchFixePieceException e) {
            throw new RuntimeException(e);
        }
        Phrase studentPhrase_new = new Phrase(studentPhrase);
        studentPhrase_new.setFixeAndChangeablePieces(studentPhrase);
        Correction correction = new Correction();
        List<ElementForCorrection> resultCorrection = correction.verify(studentPhrase_new, phraseTeacher);
        LevelOfEvaluation chooseLevel = new LevelOfEvaluation();

        Student student = userRepository.getReferenceById(exercise.getStudentId());

        int points = chooseLevel.chooseEvaluation(resultCorrection, LEVEL.valueOf(student.getLevel().toUpperCase()));
        int p = exercise.getPoints() == null ? 0 : exercise.getPoints();
        p += points;
        exercise.setPoints(p);
        exerciceRepository.save(exercise);
        if (exercise.getStudentId() != null) {

            student.setPoints(student.getPoints() + p);
            userRepository.save(student);
        }

    }
    public Exercise generatePhraseForStudent(Exercise exercise) {
        ParserRegExp parser = new ParserRegExp();
        List<Piece> parsingResult = parser.parse(exercise.getPhrase());
        String phraseForStudent = " ";
        for (Piece p : parsingResult) {
            phraseForStudent += p.pieceForStudent();
        }
        exercise.setPhraseForStudent(phraseForStudent);
        return exercise;
    }
    public void generatePhraseForCorrectAnswer(Exercise exercise) {
        ParserRegExp parser = new ParserRegExp();
        List<Piece> parsingResult = parser.parse(exercise.getPhrase());
        String phraseForCorrectAnswer= " ";
        for (Piece p : parsingResult) {
            phraseForCorrectAnswer += p.pieceForCorrectAnswer();
        }
        exercise.setPhraseForStudent(phraseForCorrectAnswer);
    }
}
