package M2IM.fr.java.verifier;

import java.util.List;

public interface Evaluation {
    int doEvaluation(List<ElementForCorrection> correctors);
}
